# Deploy Web by Zyxxennn

## What this project does
- Frontend (Next.js) with upload form (modern design)
- API route to save uploaded HTML into Supabase
- Public page to render saved HTML by ID

## Setup (local)
1. Install dependencies:
   ```
   npm install
   ```
2. Create a Supabase project and run SQL to create table:
   ```sql
   create table sites (
     id text primary key,
     name text,
     html text,
     created_at timestamp default now()
   );
   ```
3. Add environment variables in Vercel or local `.env.local`:
   ```
   SUPABASE_URL=your-supabase-url
   SUPABASE_KEY=your-service-or-anon-key
   VERCEL_URL=your-vercel-domain (e.g. deploy-web-zyxxennn.vercel.app)
   ```
4. Run locally:
   ```
   npm run dev
   ```
5. Deploy to Vercel and set the same environment variables there.

## Notes
- Use a Supabase **service role** key or anon key depending on your access rules.
- For persistent file hosting (images/assets) consider Supabase Storage or S3.
